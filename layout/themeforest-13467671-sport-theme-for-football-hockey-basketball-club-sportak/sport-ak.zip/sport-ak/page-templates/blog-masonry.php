<?php
/*
  Template Name: Blog masonry
 */
?>

<?php 
$template_name = 'masonry_post';
include(locate_template('list.php')); 
?>
