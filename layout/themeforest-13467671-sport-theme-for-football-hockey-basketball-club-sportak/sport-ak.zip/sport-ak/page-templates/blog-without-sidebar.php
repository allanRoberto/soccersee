<?php
/*
  Template Name: Blog without sidebar
 */
?>

<?php 
$show_sidebar = false;
include(locate_template('list.php')); 
?>
