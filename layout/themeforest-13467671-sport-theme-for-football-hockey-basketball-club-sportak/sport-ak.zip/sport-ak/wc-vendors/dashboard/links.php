<center>
    <p>
        <a href="<?php print $shop_page; ?>" class="button"><?php esc_html_e('View Your Store', 'wcvendors'); ?></a>
        <a href="<?php print $settings_page; ?>" class="button"><?php esc_html_e('Store Settings', 'wcvendors'); ?></a>
    </p>
</center>

<hr>