<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     10.0.0
 */
?>
<ul class="products <?php print esc_attr(get_option('woocommerce_shop_page_display')); ?>">